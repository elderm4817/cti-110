# Michael Elder
# 04/25/2025
# P4LAB1B  
# Drawing initials with turtle graphics

import turtle


gerry = turtle.Turtle()
gerry.color('#5c6358')
gerry.pensize(4)

gerry.penup()
gerry.goto(-100, 0)      
gerry.pendown()

gerry.left(90)
gerry.forward(100)
gerry.right(135)
gerry.forward(55)
gerry.left(90)
gerry.forward(55)
gerry.right(135)
gerry.forward(100)
    
gerry.penup()
gerry.goto(40, 0)      
gerry.pendown()
gerry.setheading(90)


gerry.forward(100)
gerry.right(90)
gerry.forward(50)
gerry.penup()
gerry.backward(50)
gerry.right(90)
gerry.forward(50)
gerry.left(90)
gerry.pendown()
gerry.forward(35)
gerry.penup()
gerry.backward(35)
gerry.right(90)
gerry.forward(50)
gerry.left(90)
gerry.pendown()
gerry.forward(50)

turtle.exitonclick()