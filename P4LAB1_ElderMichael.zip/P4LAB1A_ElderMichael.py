# Michael Elder
# 04/25/2025
# P4LAB1A  
# Drawing a box and triangle with for

import turtle

gerry = turtle.Turtle()
gerry.shape("turtle")

for i in range(4):
    gerry.stamp()
    gerry.forward(100)
    gerry.right(90)

gerry.left(180)

for i in range(3):
    gerry.stamp()
    gerry.forward(100)
    gerry.right(120)

    
turtle.exitonclick()

